## budhud
### A Team Fortress 2 HUD built from the ground up using #base.

## Installation, Customization, etc
https://github.com/rbjaxter/budhud/wiki

## HUD Links:
* Steam Group: http://steamcommunity.com/groups/budhud
* Discord: https://discord.gg/PTWkt3h
* Screenshots: http://imgur.com/a/aJ1K5

## HUD Credits
Full credits can be viewed here: https://github.com/rbjaxter/budhud/wiki/HUD-Credits
